<?php
// Database Configuration
// This file is automatically configured for default setup
// If you have custom MySQL credentials, update them below

$servername = "localhost";
$username = "pms_user";
$password = "pms2024";
$dbname = "construction_pms_db";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
